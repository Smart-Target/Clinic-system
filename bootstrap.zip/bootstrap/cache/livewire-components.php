<?php return array (
  'payment-medicine' => 'App\\Http\\Livewire\\PaymentMedicine',
  'payment-service' => 'App\\Http\\Livewire\\PaymentService',
  'schedule-service' => 'App\\Http\\Livewire\\ScheduleService',
);
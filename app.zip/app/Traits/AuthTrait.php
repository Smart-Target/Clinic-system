<?php

namespace App\Traits;

use App\Providers\RouteServiceProvider;

trait AuthTrait
{
    public function checkAuth($request) {
        if ($request->type == 'call_center' || $request->type == 'hr' || $request->type == 'appointment') {
            $guardName = $request->type;
        }
        else {
            $guardName = 'web';
        }
        return $guardName;
    }

    public function redirect($request) {
        if ($request->type == 'call_center') {
            return redirect()->intended(RouteServiceProvider::CALLCENTER);
        }
        elseif ($request->type == 'hr') {
            return redirect()->intended(RouteServiceProvider::HR);

        }
        elseif ($request->type == 'appointment') {
            return redirect()->intended(RouteServiceProvider::APPOINTMENT);

        }
        else {
            return redirect()->intended(RouteServiceProvider::HOME);

        }
    }
}

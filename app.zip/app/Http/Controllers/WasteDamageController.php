<?php

namespace App\Http\Controllers;

use App\Models\waste_damage;
use Illuminate\Http\Request;

class WasteDamageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\waste_damage  $waste_damage
     * @return \Illuminate\Http\Response
     */
    public function show(waste_damage $waste_damage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\waste_damage  $waste_damage
     * @return \Illuminate\Http\Response
     */
    public function edit(waste_damage $waste_damage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\waste_damage  $waste_damage
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, waste_damage $waste_damage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\waste_damage  $waste_damage
     * @return \Illuminate\Http\Response
     */
    public function destroy(waste_damage $waste_damage)
    {
        //
    }
}

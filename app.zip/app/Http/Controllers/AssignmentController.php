<?php

namespace App\Http\Controllers;

use App\Models\assignment,App\Models\assign_contact,App\Models\assign_group,App\Models\contact,App\Models\contact_group;
use App\Models\call_agent;
use App\Models\outgoing_call;
use App\Models\PhoneNumber;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use mysql_xdevapi\Exception;
use PHPUnit\Framework\ExpectationFailedException;

class AssignmentController extends Controller
{
    public function index()
    {
        //
        $assignment=assignment::latest()->paginate(10);
        return view('call_center.assignment.allassignment',compact('assignment'));
    }

    public function index2()
    {
        //
        $assignment=assignment::latest()->paginate(10);
        return view('call_center.assignment.allassignment2',compact('assignment'));
    }
    public function search(Request $request)
    {
        //
        $name=$request['name']?? "";
        $phone=$request['phone']?? "";
        $specialization=$request['specialization']?? "";
        if($name !=""){
            $assignment=assignment::where('name','LIKE',$name)->get();

        }
        elseif($phone != ""){
            $assignment=assignment::where('phone','LIKE',$phone)->get();

        }
        elseif($specialization !=""){
            $assignment=assignment::where('specialization','LIKE',$specialization)->get();
        }
        else{
            $assignment=assignment::all();
        }
        return view('call_center.assignment.allassignment',compact('assignment'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $assign_contact=contact::all();
        $assign_group=contact_group::all();
        $agents = call_agent::all();

        return view('call_center.assignment.addassignment',compact('assign_contact','assign_group', 'agents'));

    }

    public function store(Request $request)
    {
//        $assignment = assignment::create([
//            'agent_name'=> $request->agent_name,
//            'from'=> $request->from,
//            'to'=> $request->to,
//            'completness'=> $request->completness,
//            'assign_date'=> $request->assign_date,
//        ]);

        $getGroupId = contact_group::where('group_name', $request->contact)->get();
//        return $getGroupId;
        $getCalls = PhoneNumber::where('group_id', $getGroupId[0]->id)->whereRaw('phone_id BETWEEN ' . $request->from . ' AND ' . $request->to)->get();

        foreach ($getCalls as $item){
            outgoing_call::create([
                'agent_name' => $request->agent_name,
                'client_phone' => $item->phone_number,
            ]);
        }

//       $contact = $request->input('contact', []);
//       $group = $request->input('group', []);
//
//       for ($i=0; $i < count($contact); $i++) {
//
//           $assignment->assign_contact()->save(
//                new assign_contact([
//                'contact_name' =>  $contact[$i] ,
//
//            ]),);
//        }
//        for ($i=0; $i < count($group); $i++) {
//
//            $assignment->assign_group()->save(
//                new assign_group([
//                    'group_name' =>  $group[$i] ,
//                ])
//            );
//        }


       return redirect()->back()->with('success', 'Added Successfully');

    }



    /**
     * Display the specified resource.
     *
     * @param  \App\Models\assignment  $assignment
     * @return \Illuminate\Http\Response
     */
    public function show(assignment $assignment)
    {
        //
        return view('call_center.assignment.show',compact('assignment'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\assignment  $assignment
     * @return \Illuminate\Http\Response
     */
    public function edit(assignment $assignment)
    {
        //
        return view('call_center.assignment.editassignment',compact('assignment'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\assignment  $assignment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
//        //
//        $rules=[
//
//            'agent_name'=>'required',
//            'from'=>'required|date',
//            'to'=>'required|date',
////            'completness'=>'required',
//            'assign_date'=>'required',
//          ];
//
//          $msgs=[
//            'agent_name.required'=>'Please Fill This Field',
//            'from.required'=>'Please Fill This Field',
//            'from.date'=>'Please Enter valid date',
//            'to.date'=>'Please Enter valid date',
//            'to.required'=>'Please Fill This Field',
//            'completness.required'=>'Please Fill This Field',
//            'assign_date.required'=>'Please Fill This Field',
//          ];
//            $validator=Validator::make($request->all(),$rules,$msgs);
//
//            if($validator->fails()){
//                return redirect()->back()->withErrors($validator)->withInputs($request->all());
//            }
        //
        assignment::where('id', $id)->update($request->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\assignment  $assignment
     * @return \Illuminate\Http\Response
     */
    public function destroy(assignment $assignment)
    {
        //
        $assignment->delete();
        return redirect()->route('assignment.index');
    }
}

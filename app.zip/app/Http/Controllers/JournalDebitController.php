<?php

namespace App\Http\Controllers;

use App\Models\accounting\journal_debit;
use Illuminate\Http\Request;

class JournalDebitController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\accounting\journal_debit  $journal_debit
     * @return \Illuminate\Http\Response
     */
    public function show(journal_debit $journal_debit)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\accounting\journal_debit  $journal_debit
     * @return \Illuminate\Http\Response
     */
    public function edit(journal_debit $journal_debit)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\accounting\journal_debit  $journal_debit
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, journal_debit $journal_debit)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\accounting\journal_debit  $journal_debit
     * @return \Illuminate\Http\Response
     */
    public function destroy(journal_debit $journal_debit)
    {
        //
    }
}

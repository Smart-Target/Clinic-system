<?php

namespace App\Http\Controllers;

use App\Models\Specialization;
use Illuminate\Http\Request;

class SpecialsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $specials = Specialization::all();
        $i = 1;
        return view('Appointments.specialization.allSpecials', compact('specials', 'i'));
    }

    public function create()
    {
        return view('Appointments.specialization.addSpecial');
    }

    public function store(Request $request)
    {
        Specialization::create([
           'title' => $request->title
        ]);
        return redirect()->back()->with(['success' => 'Created Successfully']);
    }

    public function edit($id)
    {
        $special = Specialization::find($id);
        return view('Appointments.specialization.editSpecial', compact('special'));
    }

    public function update(Request $request, $id)
    {
        Specialization::find($id)->update($request->all());
        return redirect()->back()->with(['success' => 'Updated Successfully']);
    }

    public function destroy($id)
    {
        $special = Specialization::find($id)->delete();
        return redirect()->back()->with(['success' => 'Deleted Successfully']);
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\patient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PatientController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        //
        $patient=patient::latest()->paginate(10);
        return view('Appointments.patient.allpatient',compact('patient'));
    }

    public function index2()
    {
        $i = 1;
        $patient=patient::latest()->paginate(10);
        return view('Appointments.patient.allpatient2',compact('patient', 'i'));
    }

    public function search(Request $request)
    {
        //
        $patient_id=$request['patient_id']?? "";
        $patient_name=$request['patient_name']?? "";
        $patient_mobile=$request['patient_mobile']?? "";
        if($patient_id !=""){
            $patient=patient::where('cid','LIKE',$patient_id)->get();

        }
        elseif($patient_name != ""){
            $patient=patient::where('first_name','LIKE',$patient_name)->get();

        }
        elseif($patient_mobile !=""){
            $patient=patient::where('mobile','LIKE',$patient_mobile)->get();
        }
        else{
            $patient=patient::all();
        }
        return view('Appointments.patient.allpatient',compact('patient'));
    }

    public function create()
    {
        //
        return view('Appointments.patient.addpatient')->with('success','Created Succssefuly');
    }

    public function store(Request $request)
    {
        //
      $rules=[
        'first_name'=>'required|max:250',
        'father_name'=>'required|max:250',
        'nationality'=>'max:250',
        'social_case'=>'max:250',
        'mobile'=>'required|numeric',
        'cid'=> $request->cid != "" ? 'numeric|max:12|unique:patients' : '',
        'date_of_birth'=>$request->date_of_birth != "" ? 'date' : '',
        'email'=>$request->email != "" ? 'email' : '',
        'tel'=>$request->tel != "" ? 'numeric' : '',
        'weight'=>$request->weight != "" ? 'numeric' : '',
        'length'=>$request->length != "" ? 'numeric' : '',
        'credit_balance'=>$request->credit_balance != "" ? 'numeric' : '',
        'debit_balance'=>$request->debit_balance != "" ? 'numeric' : '',
      ];

      $msgs=[
        'first_name.required'=>'Please Fill This Field',
        'first_name.max'=>'Max Limit Exceeded',
        'father_name.required'=>'Please Fill This Field',
        'father_name.max'=>'Max Limit Exceeded',
        'mobile.required'=>'Please Fill This Field',
        'mobile.numeric'=>'Value must be number',
      ];
        $validator=Validator::make($request->all(),$rules,$msgs);

        if($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInputs($request->all());
        }
        $patient =  patient::create([
            'first_name'=>$request->first_name,
            'father_name'=>$request->father_name,
            'nationality'=>$request->nationality,
            'file_number'=>$request->file_number,
            'social_case'=>$request->social_case,
            'mobile'=>$request->mobile,
            'cid'=>$request->cid,
            'gender'=>$request->gender,
            'date_of_birth'=>$request->date_of_birth,
            'email'=>$request->email,
            'tel'=>$request->tel,
            'address'=>$request->address,
            'blood_type'=>$request->blood_type,
            'smoking'=>$request->smoking,
            'weight'=>$request->weight,
            'length'=>$request->length,
            'known_us_from'=>$request->known_us_from,
            'job'=>$request->job,
            'case'=>$request->case,
            'has_allegric_to_medicine'=>$request->has_allegric_to_medicine,
            'credit_balance'=>$request->credit_balance,
            'debit_balance'=>$request->debit_balance,
           ]);
           return redirect()->back()->with(['success' => 'Created Successfully']);

    }

    public function show(patient $patient)
    {
        //
        return view('Appointments.patient.show',compact('patient'));

    }

    public function edit(patient $patient)
    {
        //
        // dd($patient->id);
        return view('Appointments.patient.editpatient',compact('patient'));

    }

    public function update(Request $request, $id)
    {
        //
        $rules=[
            'first_name'=>'required|max:250',
            'father_name'=>'required|max:250',
            'nationality'=>'max:250',
            'social_case'=>'max:250',
            'mobile'=>'required|numeric',
            'cid'=> $request->cid != "" ? 'numeric|max:12|unique:patients' : '',
            'date_of_birth'=>$request->date_of_birth != "" ? 'date' : '',
            'email'=>$request->email != "" ? 'email' : '',
            'tel'=>$request->tel != "" ? 'numeric' : '',
            'weight'=>$request->weight != "" ? 'numeric' : '',
            'length'=>$request->length != "" ? 'numeric' : '',
            'credit_balance'=>$request->credit_balance != "" ? 'numeric' : '',
            'debit_balance'=>$request->debit_balance != "" ? 'numeric' : '',
        ];

        $msgs=[
            'first_name.required'=>'Please Fill This Field',
            'first_name.max'=>'Max Limit Exceeded',
            'father_name.required'=>'Please Fill This Field',
            'father_name.max'=>'Max Limit Exceeded',
            'mobile.required'=>'Please Fill This Field',
            'mobile.numeric'=>'Value must be number',
          ];
            $validator=Validator::make($request->all(),$rules,$msgs);

            if($validator->fails()){
                return redirect()->back()->withErrors($validator)->withInputs($request->all());
            }

        $patient = patient::find($id);
            if ($patient) {
                patient::update($request->all());
                return redirect()->back()->with('success','Updated Successfully');
            }
        return redirect()->back()->with('error','Updated Failed');
    }

    public function destroy(patient $patient)
    {

        $patient->delete();
        return redirect()->route('patient.index2');
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\nurse;
use App\Models\NurseShift;
use App\Models\Specialization;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class NurseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        //
        $nurse=nurse::latest()->paginate(10);
        return view('Appointments.nurse.allnurse',compact('nurse'));
    }
    public function index2()
    {
        //
        $nurse=nurse::latest()->paginate(10);
        return view('Appointments.nurse.allnurse2',compact('nurse'));
    }
    public function search(Request $request)
    {
        //
        $name=$request['name']?? "";
        $phone=$request['phone']?? "";
        $specialization=$request['specialization']?? "";
        if($name !=""){
            $nurse=nurse::where('name','LIKE',$name)->get();

        }
        elseif($phone != ""){
            $nurse=nurse::where('phone','LIKE',$phone)->get();

        }
        elseif($specialization !=""){
            $nurse=nurse::where('specialization','LIKE',$specialization)->get();
        }
        else{
            $nurse=nurse::all();
        }
        return view('Appointments.nurse.allnurse',compact('nurse'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $specials = Specialization::all();
        return view('Appointments.nurse.addnurse', compact('specials'))->with('success','Created Succssefuly');

    }

    public function store(Request $request)
    {

        $rules=[

            'name'=>'required|max:250',
            'phone'=>'required|numeric',
            'specialization'=>'required',

          ];

          $msgs=[
            'name.required'=>'Please Fill This Field',
            'name.max'=>'Max Limit Exceeded',
            'phone.required'=>'Please Fill This Field',
            'phone.numeric'=>'Value must be number',
            'specialization.required'=>'Please Fill This Field',
          ];
            $validator=Validator::make($request->all(),$rules,$msgs);

            if($validator->fails()){
                return redirect()->back()->withErrors($validator)->withInputs($request->all());
            }

        $nurse =  nurse::create([
            'name'=>$request->name,
            'phone'=>$request->phone,
            'nationality'=>$request->nationality,
            'address'=>$request->address,
            'specialization'=>$request->specialization
        ]);
        return redirect()->route('nurse.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\nurse  $nurse
     * @return \Illuminate\Http\Response
     */
    public function show(nurse $nurse)
    {
        //
        return view('Appointments.nurse.show',compact('nurse'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\nurse  $nurse
     * @return \Illuminate\Http\Response
     */
    public function edit(nurse $nurse)
    {
        //
        return view('Appointments.nurse.editnurse',compact('nurse'));


    }

    public function update(Request $request, $id)
    {
        //
        $rules=[

            'name'=>'required|max:250',
            'phone'=>'required|numeric|max:15',
            'address'=>'required',
            'shift'=>'required',
            'specialization'=>'required',

          ];

          $msgs=[
            'name.required'=>'Please Fill This Field',
            'name.max'=>'Max Limit Exceeded',
            'phone.required'=>'Please Fill This Field',
            'phone.max'=>'Max Limit Exceeded',
            'phone.numeric'=>'Value must be number',
            'address.required'=>'Please Fill This Field',
            'shift.required'=>'Please Fill This Field',
            'specialization.required'=>'Please Fill This Field',







          ];
//            $validator=Validator::make($request->all(),$rules,$msgs);
//
//            if($validator->fails()){
//                return redirect()->back()->withErrors($validator)->withInputs($request->all());
//            }
        nurse::find($id)->update($request->all());
        return redirect()->back()->with('success','Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\nurse  $nurse
     * @return \Illuminate\Http\Response
     */
    public function destroy(nurse $nurse)
    {
        //
        $nurse->delete();
        return redirect()->route('nurse.index');
    }

    public function shift() {
        $nurses = nurse::all();
        return view('Appointments.nurse.addShift', compact('nurses'));
    }
    public function shiftPost(Request $request) {
        NurseShift::create([
           'nurse_name' => $request->nurse_name,
           'start_shift' => $request->start_shift,
           'end_shift' => $request->end_shift,
        ]);
        return redirect()->back()->with(['success' => 'Add Shift Successfully For ' . $request->nurse_name]);
    }

    public function editShift($id) {
        $shift = NurseShift::find($id);
        return view('Appointments.nurse.editShift', compact('shift'));
    }

    public function updateShift(Request $request, $id) {
        $shift = NurseShift::find($id);
        if ($shift) {
            $shift->update($request->all());
            return redirect()->back()->with(['success' => 'Update Successful']);
        }
        return redirect()->back()->with(['error' => 'Update Failed']);
    }

    public function allShift() {
        $shifts = NurseShift::all();
        return view('Appointments.nurse.allShifts', compact('shifts'));
    }
}

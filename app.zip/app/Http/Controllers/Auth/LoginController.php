<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;

use App\Traits\AuthTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    use AuthTrait;

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function loginForm($type) {
        return view('auth.login', compact('type'));
    }

    public function loginCheck(Request $request) {
        if (Auth::guard($this->checkAuth($request))->attempt(['username' => $request->username, 'password' => $request->password])) {
            $this->redirect($request);
        }
    }
}

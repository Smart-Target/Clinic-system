<?php

namespace App\Http\Controllers;

use App\Models\hr\work_hist;
use Illuminate\Http\Request;

class WorkHistController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\hr\work_hist  $work_hist
     * @return \Illuminate\Http\Response
     */
    public function show(work_hist $work_hist)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\hr\work_hist  $work_hist
     * @return \Illuminate\Http\Response
     */
    public function edit(work_hist $work_hist)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\hr\work_hist  $work_hist
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, work_hist $work_hist)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\hr\work_hist  $work_hist
     * @return \Illuminate\Http\Response
     */
    public function destroy(work_hist $work_hist)
    {
        //
    }
}

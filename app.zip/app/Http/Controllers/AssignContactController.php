<?php

namespace App\Http\Controllers;

use App\Models\assign_contact;
use Illuminate\Http\Request;

class AssignContactController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\assign_contact  $assign_contact
     * @return \Illuminate\Http\Response
     */
    public function show(assign_contact $assign_contact)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\assign_contact  $assign_contact
     * @return \Illuminate\Http\Response
     */
    public function edit(assign_contact $assign_contact)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\assign_contact  $assign_contact
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, assign_contact $assign_contact)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\assign_contact  $assign_contact
     * @return \Illuminate\Http\Response
     */
    public function destroy(assign_contact $assign_contact)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\call_agent;
use App\Models\contact;
use App\Models\contact_group;
use App\Models\incoming_call;
use App\Models\KnowUs;
use App\Models\outgoing_call;
use App\Models\patient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class call_centerController extends Controller
{

    public function index()
    {
        if (auth()->user()->type == 1) {
            $outgoing_calls = outgoing_call::where('call_date', date('Y-m-d'))->get()->count();
            $incoming_calls = incoming_call::where('call_date', date('Y-m-d'))->get()->count();
            $interested_calls = incoming_call::where('call_case', 'LIKE', 'interested%')->where('call_date', date('Y-m-d'))->get()->count() + outgoing_call::where('call_case', 'LIKE', 'interested%')->where('call_date', date('Y-m-d'))->get()->count();
            $not_interested_calls = incoming_call::where('call_case', 'LIKE', 'not%')->where('call_date', date('Y-m-d'))->get()->count() + outgoing_call::where('call_case', 'LIKE', 'not%')->where('call_date', date('Y-m-d'))->get()->count();
        }
        else {
            $outgoing_calls = outgoing_call::where('agent_name', auth()->user()->name)->where('call_date', date('Y-m-d'))->get()->count();
            $incoming_calls = incoming_call::where('agent_name', auth()->user()->name)->where('call_date', date('Y-m-d'))->get()->count();
            $interested_calls = incoming_call::where('agent_name', auth()->user()->name)->where('call_case', 'LIKE', 'interested%')->where('call_date', date('Y-m-d'))->get()->count() + outgoing_call::where('call_case', 'LIKE', 'interested%')->where('call_date', date('Y-m-d'))->get()->count();
            $not_interested_calls = incoming_call::where('agent_name', auth()->user()->name)->where('call_case', 'LIKE', 'not%')->where('call_date', date('Y-m-d'))->get()->count() + outgoing_call::where('call_case', 'LIKE', 'not%')->where('call_date', date('Y-m-d'))->get()->count();
        }
        return view('call_center.index', compact('outgoing_calls', 'incoming_calls', 'interested_calls', 'not_interested_calls'));
    }

    public function loginForm() {
        return view('call_center.login');
    }

    public function login(Request $request) {
        $call_center = array(
            'username' => $request->input('username'),
            'password' => $request->input('password'),
        );

        if (Auth::guard('call_center')->attempt($call_center)) {
            return Redirect::intended('/call_center');
        }

        return redirect()->back()->with(['error' => 'Your Email Or Your Password Is Wrong'])->withInput($request->all());
    }

    public function logout() {
        Auth::guard('call_center')->logout();
        return redirect()->route('call_center.login.show');
    }

    public function assign() {
        $assign_contact=contact::all();
        $assign_group=contact_group::all();
        $agents = call_agent::all();
        return view('call_center.more_additions.addAssignment',compact('assign_contact','assign_group', 'agents'));
    }

    public function knowUs() {
        $knowUs = KnowUs::all();
        return view('call_center.more_additions.knowUs',compact('knowUs'));
    }


    public function knowUsPost(Request $request) {
        KnowUs::create([
            'title' => $request->platform
        ]);
        return redirect()->back()->with(['success' => 'Created Successfully']);
    }

    public function KnowUsdestroy($id)
    {
        KnowUs::find($id)->delete();
        return redirect()->back();
    }

    public function change() {
        $assign_contact=contact::all();
        $contact_group=contact_group::all();
        $agents = call_agent::all();
        return view('call_center.more_additions.changeAssignment',compact('assign_contact','contact_group', 'agents'));
    }

    public function changePost(Request $request) {
        if ($request->type == "1") {
            outgoing_call::where('call_case', 'Like', 'Not-Interested%')->update(['agent_name' => $request->agent_name]);
            incoming_call::where('call_case', 'Like', 'Not-Interested%')->update(['agent_name' => $request->agent_name]);
        }

        elseif ($request->type == "2") {
            outgoing_call::where('client_phone', $request->phone)->update(['agent_name' => $request->agent_name]);
            incoming_call::where('phone', $request->phone)->update(['agent_name' => $request->agent_name]);
        }

        else {
            if ($request->case == "Interested") {
                outgoing_call::where('call_group', $request->group)->where('call_case', $request->case . " " . $request->case_percent)->update(['agent_name' => $request->agent_name]);
                incoming_call::where('call_group', $request->group)->where('call_case', $request->case . " " . $request->case_percent)->update(['agent_name' => $request->agent_name]);
            }
            else {
                outgoing_call::where('call_group', $request->group)->where('call_case', $request->case)->update(['agent_name' => $request->agent_name]);
                incoming_call::where('call_group', $request->group)->where('call_case', $request->case)->update(['agent_name' => $request->agent_name]);
            }
        }
        return redirect()->back()->with(['changed' => 'Changed Successfully']);
    }


    public function event(Request $request) {
        if ($request->ajax())
            return "hello";
        $time_show = [
            '12:00 AM',
            '12:15 AM',
            '12:30 AM',
            '12:45 AM',
            '01:00 AM',
            '01:15 AM',
            '01:30 AM',
            '01:45 AM',
            '02:00 AM',
            '02:15 AM',
            '02:30 AM',
            '02:45 AM',
            '03:00 AM',
            '03:15 AM',
            '03:30 AM',
            '03:45 AM',
            '04:00 AM',
            '04:15 AM',
            '04:30 AM',
            '04:45 AM',
            '05:00 AM',
            '05:15 AM',
            '05:30 AM',
            '05:45 AM',
            '06:00 AM',
            '06:15 AM',
            '06:30 AM',
            '06:45 AM',
            '07:00 AM',
            '07:15 AM',
            '07:30 AM',
            '07:45 AM',
            '08:00 AM',
            '08:15 AM',
            '08:30 AM',
            '08:45 AM',
            '09:00 AM',
            '09:15 AM',
            '09:30 AM',
            '09:45 AM',
            '10:00 AM',
            '10:15 AM',
            '10:30 AM',
            '10:45 AM',
            '11:00 AM',
            '11:15 AM',
            '11:30 AM',
            '11:45 AM',
            '12:00 PM',
            '12:15 PM',
            '12:30 PM',
            '12:45 PM',
            '01:00 PM',
            '01:15 PM',
            '01:30 PM',
            '01:45 PM',
            '02:00 PM',
            '02:15 PM',
            '02:30 PM',
            '02:45 PM',
            '03:00 PM',
            '03:15 PM',
            '03:30 PM',
            '03:45 PM',
            '04:00 PM',
            '04:15 PM',
            '04:30 PM',
            '04:45 PM',
            '05:00 PM',
            '05:15 PM',
            '05:30 PM',
            '05:45 PM',
            '06:00 PM',
            '06:15 PM',
            '06:30 PM',
            '06:45 PM',
            '07:00 PM',
            '07:15 PM',
            '07:30 PM',
            '07:45 PM',
            '08:00 PM',
            '08:15 PM',
            '08:30 PM',
            '08:45 PM',
            '09:00 PM',
            '09:15 PM',
            '09:30 PM',
            '09:45 PM',
            '10:00 PM',
            '10:15 PM',
            '10:30 PM',
            '10:45 PM',
            '11:00 PM',
            '11:15 PM',
            '11:30 PM',
            '11:45 PM',
        ];
        $time_data_set = [
            "00:00",
            "00:15",
            "00:30",
            "00:45",
            "01:00",
            "01:15",
            "01:30",
            "01:45",
            "02:00",
            "02:15",
            "02:30",
            "02:45",
            "03:00",
            "03:15",
            "03:30",
            "03:45",
            "04:00",
            "04:15",
            "04:30",
            "04:45",
            "05:00",
            "05:15",
            "05:30",
            "05:45",
            "06:00",
            "06:15",
            "06:30",
            "06:45",
            "07:00",
            "07:15",
            "07:30",
            "07:45",
            "08:00",
            "08:15",
            "08:30",
            "08:45",
            "09:00",
            "09:15",
            "09:30",
            "09:45",
            "10:00",
            "10:15",
            "10:30",
            "10:45",
            "11:00",
            "11:15",
            "11:30",
            "11:45",
            "12:00",
            "12:15",
            "12:30",
            "12:45",
            "13:00",
            "13:15",
            "13:30",
            "13:45",
            "14:00",
            "14:15",
            "14:30",
            "14:45",
            "15:00",
            "15:15",
            "15:30",
            "15:45",
            "16:00",
            "16:15",
            "16:30",
            "16:45",
            "17:00",
            "17:15",
            "17:30",
            "17:45",
            "18:00",
            "18:15",
            "18:30",
            "18:45",
            "19:00",
            "19:15",
            "19:30",
            "19:45",
            "20:00",
            "20:15",
            "20:30",
            "20:45",
            "21:00",
            "21:15",
            "21:30",
            "21:45",
            "22:00",
            "22:15",
            "22:30",
            "22:45",
            "23:00",
            "23:15",
            "23:30",
            "23:45",
        ];
        $service1 = Appointment::where('service', 'clean')->where('appointment_date', date('Y-m-d'))->get()->toArray();
        $count1 = Appointment::where('service', 'clean')->where('appointment_date', date('Y-m-d'))->get(['count']);
        $service2 = Appointment::where('service', 'laser')->where('appointment_date', date('Y-m-d'))->get()->toArray();
        $service3 = Appointment::where('service', 'smart')->where('appointment_date', date('Y-m-d'))->get()->toArray();
        return view('call_center.full_calender', compact('service1', 'count1', 'service2', 'service3', 'time_show', 'time_data_set'));
    }

    public function setDate(Request $request) {
        $date = $request->date;
        $time_show = [
            '12:00 AM',
            '12:15 AM',
            '12:30 AM',
            '12:45 AM',
            '01:00 AM',
            '01:15 AM',
            '01:30 AM',
            '01:45 AM',
            '02:00 AM',
            '02:15 AM',
            '02:30 AM',
            '02:45 AM',
            '03:00 AM',
            '03:15 AM',
            '03:30 AM',
            '03:45 AM',
            '04:00 AM',
            '04:15 AM',
            '04:30 AM',
            '04:45 AM',
            '05:00 AM',
            '05:15 AM',
            '05:30 AM',
            '05:45 AM',
            '06:00 AM',
            '06:15 AM',
            '06:30 AM',
            '06:45 AM',
            '07:00 AM',
            '07:15 AM',
            '07:30 AM',
            '07:45 AM',
            '08:00 AM',
            '08:15 AM',
            '08:30 AM',
            '08:45 AM',
            '09:00 AM',
            '09:15 AM',
            '09:30 AM',
            '09:45 AM',
            '10:00 AM',
            '10:15 AM',
            '10:30 AM',
            '10:45 AM',
            '11:00 AM',
            '11:15 AM',
            '11:30 AM',
            '11:45 AM',
            '12:00 PM',
            '12:15 PM',
            '12:30 PM',
            '12:45 PM',
            '01:00 PM',
            '01:15 PM',
            '01:30 PM',
            '01:45 PM',
            '02:00 PM',
            '02:15 PM',
            '02:30 PM',
            '02:45 PM',
            '03:00 PM',
            '03:15 PM',
            '03:30 PM',
            '03:45 PM',
            '04:00 PM',
            '04:15 PM',
            '04:30 PM',
            '04:45 PM',
            '05:00 PM',
            '05:15 PM',
            '05:30 PM',
            '05:45 PM',
            '06:00 PM',
            '06:15 PM',
            '06:30 PM',
            '06:45 PM',
            '07:00 PM',
            '07:15 PM',
            '07:30 PM',
            '07:45 PM',
            '08:00 PM',
            '08:15 PM',
            '08:30 PM',
            '08:45 PM',
            '09:00 PM',
            '09:15 PM',
            '09:30 PM',
            '09:45 PM',
            '10:00 PM',
            '10:15 PM',
            '10:30 PM',
            '10:45 PM',
            '11:00 PM',
            '11:15 PM',
            '11:30 PM',
            '11:45 PM',
        ];
        $time_data_set = [
            "00:00",
            "00:15",
            "00:30",
            "00:45",
            "01:00",
            "01:15",
            "01:30",
            "01:45",
            "02:00",
            "02:15",
            "02:30",
            "02:45",
            "03:00",
            "03:15",
            "03:30",
            "03:45",
            "04:00",
            "04:15",
            "04:30",
            "04:45",
            "05:00",
            "05:15",
            "05:30",
            "05:45",
            "06:00",
            "06:15",
            "06:30",
            "06:45",
            "07:00",
            "07:15",
            "07:30",
            "07:45",
            "08:00",
            "08:15",
            "08:30",
            "08:45",
            "09:00",
            "09:15",
            "09:30",
            "09:45",
            "10:00",
            "10:15",
            "10:30",
            "10:45",
            "11:00",
            "11:15",
            "11:30",
            "11:45",
            "12:00",
            "12:15",
            "12:30",
            "12:45",
            "13:00",
            "13:15",
            "13:30",
            "13:45",
            "14:00",
            "14:15",
            "14:30",
            "14:45",
            "15:00",
            "15:15",
            "15:30",
            "15:45",
            "16:00",
            "16:15",
            "16:30",
            "16:45",
            "17:00",
            "17:15",
            "17:30",
            "17:45",
            "18:00",
            "18:15",
            "18:30",
            "18:45",
            "19:00",
            "19:15",
            "19:30",
            "19:45",
            "20:00",
            "20:15",
            "20:30",
            "20:45",
            "21:00",
            "21:15",
            "21:30",
            "21:45",
            "22:00",
            "22:15",
            "22:30",
            "22:45",
            "23:00",
            "23:15",
            "23:30",
            "23:45",
        ];
        $service1 = Appointment::where('service', 'clean')->where('appointment_date', $date)->get();
        $service2 = Appointment::where('service', 'laser')->where('appointment_date', $date)->get();
        $service3 = Appointment::where('service', 'smart')->where('appointment_date', $date)->get();
        return view('call_center.full_calender', compact('service1', 'service2', 'service3', 'time_show', 'time_data_set', 'date'));
    }

    public function action(Request $request) {
        if ($request->patient_type == 'new') {
            patient::create([
                'patient_name' => $request->patient_name,
                'mobile' => $request->patient_phone,
                'file_number' => time(),
            ]);
        }
        Appointment::create([
            'patient_name' => $request->patient_name,
            'service' => $request->service,
            'appointment_date' => $request->appointment_date,
            'appointment_time' => $request->appointment_time,
            'appointment_time_end' => $request->appointment_time_end,
            'count' => 4*(($request->appointment_time_end[0] . $request->appointment_time_end[1]) - ($request->appointment_time[1] . $request->appointment_time[0])) + (($request->appointment_time_end[3] . $request->appointment_time_end[4]) - ($request->appointment_time[3] . $request->appointment_time[4]))/15 + 1,
        ]);
        return redirect()->back()->with('success' , 'Appointment Successfully');
    }

    public function editAppointment(Request $request) {
        $appoint = Appointment::find($request->id);
        if (!$appoint)
            return redirect()->back()->with('danger', 'Updated Failed');
        $appoint->update([
            'patient_name' => $request->patient_name,
            'service' => $request->service,
            'appointment_date' => $request->appointment_date,
            'appointment_time' => $request->appointment_time,
            'appointment_time_end' => $request->appointment_time_end,
            'count' => 4*(($request->appointment_time_end[0] . $request->appointment_time_end[1]) - ($request->appointment_time[1] . $request->appointment_time[0])) + (($request->appointment_time_end[3] . $request->appointment_time_end[4]) - ($request->appointment_time[3] . $request->appointment_time[4]))/15 + 1,
        ]);
        return redirect()->back()->with('success', 'Updated Successfully');
    }

}

<?php

namespace App\Http\Controllers;

use App\Models\call_agent;
use App\Models\contact;
use App\Models\contact_group;
use App\Models\PhoneNumber;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\NumberImport;

class ContactGroupController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        //
        $contact_group=contact_group::latest()->paginate(10);
        return view('call_center.contact_group.allcontact_group',compact('contact_group'));
    }

    public function index2()
    {
        //
        $contact_group=contact_group::latest()->paginate(10);
        return view('call_center.contact_group.allcontact_group2',compact('contact_group'));
    }
    public function search(Request $request)
    {
        //
        $name=$request['name']?? "";
        if($name !=""){
            $contact_group=contact_group::where('group_name','LIKE', "%" . $name . "%")->get();

        }
        else{
            $contact_group=contact_group::all();
        }
        return view('call_center.contact_group.allcontact_group',compact('contact_group'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('call_center.contact_group.addcontact_group');

    }

    public function store(Request $request)
    {
        $time = time();
        contact_group::create([
            'id' => $time,
            'group_name'=>$request->group_name,
        ]);
        $checkGroup = contact_group::where('group_name', $request->group_name)->get();
        $file = $request->file('excel_file');
        Excel::import(new NumberImport,$file);
//        PhoneNumber::where('created_at', $checkGroup[0]->created_at)
//            ->update(['group_id' => $checkGroup[0]->id]);

        return redirect()->back()->with('success', 'Created Successfully');
    }

    public function show(contact_group $contact_group)
    {
        return view('call_center.contact_group.show',compact('contact_group'));
    }

    public function edit(contact_group $contact_group)
    {
        $contacts = PhoneNumber::where('group_id', $contact_group->id)->get();
        return view('call_center.contact_group.editcontact_group',compact('contact_group', 'contacts'));
    }

    public function update(Request $request, contact_group $contact_group)
    {
        $rules=[
            'group_name'=>'required',
        ];

        $msgs=[
            'group_name.required'=>'Please Fill This Field',
        ];
        $validator=Validator::make($request->all(),$rules,$msgs);

        if($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInputs($request->all());
        }

        $contact_group->update($request->all());
        return redirect()->back()->with('success', 'Updated Successfully');
    }

    public function destroy(contact_group $contact_group)
    {
        $contact_group->delete();
        return redirect()->back()->with('success', 'Deleted Successfully');
    }
}

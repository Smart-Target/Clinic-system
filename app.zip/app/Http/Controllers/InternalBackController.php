<?php

namespace App\Http\Controllers;

use App\Models\internal_back;
use Illuminate\Http\Request;

class InternalBackController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\internal_back  $internal_back
     * @return \Illuminate\Http\Response
     */
    public function show(internal_back $internal_back)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\internal_back  $internal_back
     * @return \Illuminate\Http\Response
     */
    public function edit(internal_back $internal_back)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\internal_back  $internal_back
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, internal_back $internal_back)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\internal_back  $internal_back
     * @return \Illuminate\Http\Response
     */
    public function destroy(internal_back $internal_back)
    {
        //
    }
}

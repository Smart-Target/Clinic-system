<?php

namespace App\Http\Controllers;

use App\Models\supplier_offer;
use Illuminate\Http\Request;

class SupplierOfferController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\supplier_offer  $supplier_offer
     * @return \Illuminate\Http\Response
     */
    public function show(supplier_offer $supplier_offer)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\supplier_offer  $supplier_offer
     * @return \Illuminate\Http\Response
     */
    public function edit(supplier_offer $supplier_offer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\supplier_offer  $supplier_offer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, supplier_offer $supplier_offer)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\supplier_offer  $supplier_offer
     * @return \Illuminate\Http\Response
     */
    public function destroy(supplier_offer $supplier_offer)
    {
        //
    }
}

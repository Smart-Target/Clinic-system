<?php

namespace App\Http\Controllers;

use App\Models\AgentLogin;
use App\Models\call_agent;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class CallAgentController extends Controller
{

    public function index()
    {
        //
        $call_agent=call_agent::latest()->paginate(10);
        return view('call_center.call_agent.allcall_agent',compact('call_agent'));
    }

    public function search(Request $request)
    {
        //
        $name=$request['name']?? "";
        $phone=$request['phone']?? "";
        $email=$request['email']?? "";
        if($name !=""){
            $call_agent=call_agent::where('agent_name','LIKE',$name . "%")->get();

        }
        elseif($phone != ""){
            $call_agent=call_agent::where('phone','LIKE',$phone . "%")->get();

        }
        elseif($email !=""){
            $call_agent=call_agent::where('login','LIKE',$email . "%")->get();
        }
        else{
            $call_agent=call_agent::all();
        }
        return view('call_center.call_agent.allcall_agent',compact('call_agent'));
    }

    public function create()
    {
        //
        return view('call_center.call_agent.addcall_agent')->with('success','Created Successfully');

    }

    public function store(Request $request)
    {

        call_agent::create([
           'agent_name'=>$request->agent_name,
           'phone'=>$request->phone,
       ]);

        AgentLogin::create([
           'name'=>$request->agent_name,
           'username'=>$request->username,
           'password'=>bcrypt($request->password),
       ]);
       return redirect()->back()->with('success', 'Created Successfully');

    }

    public function show(call_agent $call_agent)
    {
        //
        return view('call_center.call_agent.show',compact('call_agent'));

    }

    public function edit(call_agent $call_agent)
    {
        //
        return view('call_center.call_agent.editcall_agent',compact('call_agent'));

    }

    public function update(Request $request, call_agent $call_agent)
    {
        //
        $rules=[
            'login'=>'required',
            'agent_name'=>'required',
          ];

          $msgs=[
            'login.required'=>'Please Fill This Field',
            'agent_name.required'=>'Please Fill This Field',
          ];
            $validator=Validator::make($request->all(),$rules,$msgs);

            if($validator->fails()){
                return redirect()->back()->withErrors($validator)->withInputs($request->all());
            }

        $call_agent->update($request->all());
        return redirect()->route('call_agent.index')
        ->with('success','update success');
    }

    public function destroy(call_agent $call_agent)
    {

        $call_agent->delete();
        return redirect()->back();
    }


}

<?php

namespace App\Http\Controllers;

use App\Models\assign_group;
use Illuminate\Http\Request;

class AssignGroupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\assign_group  $assign_group
     * @return \Illuminate\Http\Response
     */
    public function show(assign_group $assign_group)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\assign_group  $assign_group
     * @return \Illuminate\Http\Response
     */
    public function edit(assign_group $assign_group)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\assign_group  $assign_group
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, assign_group $assign_group)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\assign_group  $assign_group
     * @return \Illuminate\Http\Response
     */
    public function destroy(assign_group $assign_group)
    {
        //
    }
}

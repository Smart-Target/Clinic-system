<?php

namespace App\Http\Controllers;

use App\Models\call_agent;
use App\Models\incoming_call;
use App\Models\outgoing_call;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportsController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index() {

        $agents = call_agent::all();
        $agent_name = '';

        $outgoing_calls = 0;
        $incoming_calls = 0;
        $interested_calls = 0;
        $interested75_calls = 0;
        $interested50_calls = 0;
        $interested25_calls = 0;
        $not_interested_calls = 0;
        $disconnect_calls = 0;
        $wrong_calls = 0;
        $appointment_calls = 0;
        $later_calls = 0;
        $busy_calls = 0;

        return view('call_center.reports.allReports',compact('outgoing_calls', 'incoming_calls', 'interested_calls', 'interested75_calls', 'interested50_calls', 'interested25_calls', 'not_interested_calls', 'disconnect_calls', 'wrong_calls', 'appointment_calls', 'later_calls', 'busy_calls', 'agents', 'agent_name'));
    }

    public function search(Request $request) {

        $outgoing_calls = outgoing_call::where('agent_name', '=', $request->search_agent)->whereRaw('call_date BETWEEN "' . $request->search_date_from . '" AND "' . $request->search_date_to . '"')->get()->count();
        $incoming_calls = incoming_call::where('agent_name', '=', $request->search_agent)->whereRaw('call_date BETWEEN "' . $request->search_date_from . '" AND "' . $request->search_date_to . '"')->get()->count();
        $interested_calls = incoming_call::where('agent_name', '=', '"' . $request->search_agent . '"')->whereRaw('call_date BETWEEN "' . $request->search_date_from . '" AND "' . $request->search_date_to . '"')->where('call_case', 'LIKE', 'interested%')->get()->count() + outgoing_call::where('created_at', 'LIKE', $request->search_date . '%')->where('agent_name', '=', $request->search_agent)->where('call_case', 'LIKE', 'interested%')->get()->count();
        $interested75_calls = incoming_call::where('agent_name', '=', '"' . $request->search_agent . '"')->whereRaw('call_date BETWEEN "' . $request->search_date_from . '" AND "' . $request->search_date_to . '"')->where('call_case', 'LIKE', 'interested 75%')->get()->count() + outgoing_call::where('created_at', 'LIKE', $request->search_date . '%')->where('agent_name', '=', $request->search_agent)->where('call_case', 'LIKE', 'interested 75%')->get()->count();
        $interested50_calls = incoming_call::where('agent_name', '=', '"' . $request->search_agent . '"')->whereRaw('call_date BETWEEN "' . $request->search_date_from . '" AND "' . $request->search_date_to . '"')->where('call_case', 'LIKE', 'interested 50%')->get()->count() + outgoing_call::where('created_at', 'LIKE', $request->search_date . '%')->where('agent_name', '=', $request->search_agent)->where('call_case', 'LIKE', 'interested 50%')->get()->count();
        $interested25_calls = incoming_call::where('agent_name', '=', '"' . $request->search_agent . '"')->whereRaw('call_date BETWEEN "' . $request->search_date_from . '" AND "' . $request->search_date_to . '"')->where('call_case', 'LIKE', 'interested 25%')->get()->count() + outgoing_call::where('created_at', 'LIKE', $request->search_date . '%')->where('agent_name', '=', $request->search_agent)->where('call_case', 'LIKE', 'interested 25%')->get()->count();
        $not_interested_calls = incoming_call::where('agent_name', '=', '"' . $request->search_agent . '"')->whereRaw('call_date BETWEEN "' . $request->search_date_from . '" AND "' . $request->search_date_to . '"')->where('call_case', 'LIKE', 'not%')->get()->count() + outgoing_call::where('created_at', 'LIKE', $request->search_date . '%')->where('agent_name', '=', $request->search_agent)->where('call_case', 'LIKE', 'not%')->get()->count();
        $disconnect_calls = incoming_call::where('agent_name', '=', '"' . $request->search_agent . '"')->whereRaw('call_date BETWEEN "' . $request->search_date_from . '" AND "' . $request->search_date_to . '"')->where('call_case', 'LIKE', 'Disconnect%')->get()->count() + outgoing_call::where('created_at', 'LIKE', $request->search_date . '%')->where('agent_name', '=', $request->search_agent)->where('call_case', 'LIKE', 'Disconnect%')->get()->count();
        $wrong_calls = incoming_call::where('agent_name', '=', '"' . $request->search_agent . '"')->whereRaw('call_date BETWEEN "' . $request->search_date_from . '" AND "' . $request->search_date_to . '"')->where('call_case', 'LIKE', 'Wrong%')->get()->count() + outgoing_call::where('created_at', 'LIKE', $request->search_date . '%')->where('agent_name', '=', $request->search_agent)->where('call_case', 'LIKE', 'Wrong%')->get()->count();
        $appointment_calls = incoming_call::where('agent_name', '=', '"' . $request->search_agent . '"')->whereRaw('call_date BETWEEN "' . $request->search_date_from . '" AND "' . $request->search_date_to . '"')->where('call_case', 'LIKE', 'Appointment%')->get()->count() + outgoing_call::where('created_at', 'LIKE', $request->search_date . '%')->where('agent_name', '=', $request->search_agent)->where('call_case', 'LIKE', 'Appointment%')->get()->count();
        $later_calls = incoming_call::where('agent_name', '=', '"' . $request->search_agent . '"')->whereRaw('call_date BETWEEN "' . $request->search_date_from . '" AND "' . $request->search_date_to . '"')->where('call_case', 'LIKE', '%Later')->get()->count() + outgoing_call::where('created_at', 'LIKE', $request->search_date . '%')->where('agent_name', '=', $request->search_agent)->where('call_case', 'LIKE', '%Later')->get()->count();
        $busy_calls = incoming_call::where('agent_name', '=', '"' . $request->search_agent . '"')->whereRaw('call_date BETWEEN "' . $request->search_date_from . '" AND "' . $request->search_date_to . '"')->where('call_case', 'LIKE', 'Busy%')->get()->count() + outgoing_call::where('created_at', 'LIKE', $request->search_date . '%')->where('agent_name', '=', $request->search_agent)->where('call_case', 'LIKE', 'Busy%')->get()->count();

        $agents = call_agent::all();

        $date_from = $request->search_date_from;
        $date_to = $request->search_date_to;
        $agent_name = $request->search_agent;

        return view('call_center.reports.allReports',compact('outgoing_calls', 'incoming_calls', 'interested_calls', 'interested75_calls', 'interested50_calls', 'interested25_calls', 'not_interested_calls', 'disconnect_calls', 'wrong_calls', 'appointment_calls', 'later_calls', 'busy_calls', 'date_from', 'date_to', 'agents', 'agent_name'));
    }

    public function checkNumberGet() {
        return view('call_center.reports.checkNumber');
    }

    public function checkNumberPost(Request $request)
    {
        $number = $request->check_number;
        $find_client = outgoing_call::where('client_phone', '=', $request->check_number)->count();
//        return $find_client;
        if ($find_client == 0) {
            $find_client2 = incoming_call::where('client_phone', '=', $request->check_number)->count();
            if ($find_client2 == 0) {
                return redirect()->back()->with('error', $number . ' is not available');
            }
            else {
                $client = incoming_call::where('client_phone', '=', $request->check_number)->get();
            }
        }
        else {
            $client = outgoing_call::where('client_phone', '=', $request->check_number)->get();
        }
        return view('call_center.reports.checkNumber', compact('client', 'number'));
    }

    public function getAppointment() {
        return view('call_center.reports.appointment');
    }

    public function postAppointment(Request $request) {
        if ($request->case == 'all') {
            $data = outgoing_call::all();
        }
        else {
            $data = outgoing_call::whereRaw('call_date BETWEEN "'. $request->date_from . '" AND "' . $request->date_to . '"')->where('call_case', 'LIKE' , $request->case . '%')->get();
        }
        $case = $request->case;
        $from = $request->date_from;
        $to = $request->date_to;
        return view('call_center.reports.appointment', compact('data', 'from', 'to', 'case'));
    }
}

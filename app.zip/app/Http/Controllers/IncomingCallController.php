<?php

namespace App\Http\Controllers;

use App\Models\incoming_call,App\Models\schedule,App\Models\nurse,App\Models\doctor,App\Models\contact_group;
use App\Models\KnowUs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
class IncomingCallController extends Controller
{

    public function calender()
    {
        //
        $nurses=nurse::all();
        $doctors=doctor::all();
        $events=array();
        $schedules=schedule::all();
        foreach($schedules as $schedule){

            $color = null;
            if($schedule->work == 'Laser duetto') {
                $color = '#99004C';
            }
            if($schedule->work == 'Facial') {
                $color = '#FF99FF';
            }
            if($schedule->work == 'DeerMachine/Smart Shape2') {
                $color = '#9999FF';
            }
            if($schedule->work == 'IBL laser') {
                $color = '#99FFFF';
            }
            if($schedule->work == 'Micro Blending') {
                $color = '#99FF33';
            }
            if($schedule->work == 'Dr Rowda Sercslm') {
                $color = '#009999';
            }
            if($schedule->work == 'Laser Candela') {
                $color = '#FF0000';
            }
            if($schedule->work == 'Waiiting') {
                $color = '#C0C0C0';
            }
            if($schedule->work == 'Smart Shape 1') {
                $color = '#FF8000';
            }
            if($schedule->work == 'laser Duetto 2') {
                $color = '#FFFF00';
            }
            if($schedule->work == 'room10') {
                $color = '#660066';
            }


            $events[]=[
                'id'=> $schedule->id  ,
                'title'=>"Patient Name: ".$schedule->patient_name."    ||Work :".$schedule->work.$schedule->id,
                'start'=>$schedule->schedule_start,
                'end'=>$schedule->schedule_end,
                'color'=>$color
                // 'work'=>$schedule->work,


            ];

        }
        return view('call_center.incoming_call.appointments_cal',['events'=>$events,'nurses'=> $nurses,'doctors'=>$doctors]);
    }

    public function followup_in()
    {
        $incoming_call = incoming_call::where('recalldate', date('Y-m-d'))->get();
        return view('call_center.incoming_call.followup_in',compact('incoming_call'));
    }

    public function index()
    {
        $incoming_call=auth()->user()->type == 0 ? incoming_call::latest()->where('agent_name', auth()->user()->name)->get() : incoming_call::latest()->get();
        return view('call_center.incoming_call.allincoming_call',compact('incoming_call'));
    }

    public function search(Request $request)
    {
        //
        $name=$request['name']?? "";
        $phone=$request['phone']?? "";
        if($name !=""){
            $incoming_call=incoming_call::where('client_name','LIKE',$name)->get();

        }
        elseif($phone != ""){
            $incoming_call=incoming_call::where('client_phone','LIKE',$phone)->get();

        }
        else{
            $incoming_call=incoming_call::all();
        }
        return view('call_center.incoming_call.allincoming_call',compact('incoming_call'));
    }

    public function create()
    {
        $know_us = KnowUs::all();
        return view('call_center.incoming_call.addincoming_call',compact('know_us'))->with('success','Created Successfully');

    }

    public function store(Request $request)
    {
        $rules=[
            'client_phone' => 'numeric|unique:incoming_calls',
        ];
        $validator=Validator::make($request->all(),$rules);

        if($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInput($request->all());
        }

        incoming_call::create([
            'agent_name'=>Auth::user()->name,
            'client_name'=>$request->client_name,
            'client_phone'=>$request->client_phone,
            'call_date' => date('Y-m-d'),
            'lastcalldate'=>$request->lastcalldate,
            'recalldate'=>$request->recalldate,
            'call_case'=>$request->case_percent ? $request->call_case . " " . $request->case_percent : $request->call_case,
            'notes'=>$request->notes,
            'know_us_from'=>$request->know_us_from,
        ]);
        return redirect()->back()->with(['success' => 'Created Successfully']);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\incoming_call  $incoming_call
     * @return \Illuminate\Http\Response
     */
    public function show(incoming_call $incoming_call)
    {
        //
        return view('call_center.incoming_call.show',compact('incoming_call'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\incoming_call  $incoming_call
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $contact_group=contact_group::all();
        $incoming_call=incoming_call::find($id);

        return view('call_center.incoming_call.editincoming_call',compact('incoming_call', 'contact_group'));

    }

    public function update(Request $request, $id)
    {
        incoming_call::find($id)->update($request->all());
        return redirect()->back()->with('success','update success');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\incoming_call  $incoming_call
     * @return \Illuminate\Http\Response
     */
    public function destroy(incoming_call $incoming_call)
    {
        //
        $incoming_call->delete();
        return redirect()->route('incoming_call.index');
    }



}

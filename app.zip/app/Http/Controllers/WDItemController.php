<?php

namespace App\Http\Controllers;

use App\Models\w_d_item;
use Illuminate\Http\Request;

class WDItemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\w_d_item  $w_d_item
     * @return \Illuminate\Http\Response
     */
    public function show(w_d_item $w_d_item)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\w_d_item  $w_d_item
     * @return \Illuminate\Http\Response
     */
    public function edit(w_d_item $w_d_item)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\w_d_item  $w_d_item
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, w_d_item $w_d_item)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\w_d_item  $w_d_item
     * @return \Illuminate\Http\Response
     */
    public function destroy(w_d_item $w_d_item)
    {
        //
    }
}

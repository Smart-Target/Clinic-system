<?php

namespace App\Http\Controllers;
use App\Models\call_agent;
use Illuminate\Support\Facades\DB;
use App\Models\outgoing_call,App\Models\schedule,App\Models\nurse,App\Models\doctor,App\Models\contact_group,App\Models\patient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth
    ;
use Illuminate\Validation\Rule;

class OutgoingCallController extends Controller
{

    public function index()
    {
        $outgoing_call= auth()->user()->type == 0 ? outgoing_call::latest()->where('agent_name', auth()->user()->name)->get() : outgoing_call::latest()->get();
        return view('call_center.outgoing_call.alloutgoing_call',compact('outgoing_call'));
    }

    public function followup_out()
    {
        $outgoing_call = outgoing_call::where('recalldate', date('Y-m-d'))->get();
        return view('call_center.outgoing_call.followup_out',compact('outgoing_call'));
    }

    public function search(Request $request)
    {
        $name=$request['name']?? "";
        $phone=$request['phone']?? "";
        $specialization=$request['specialization']?? "";
        if($name !=""){
            $outgoing_call=outgoing_call::where('client_name','LIKE',$name)->get();
        }
        elseif($phone != ""){
            $outgoing_call=outgoing_call::where('client_phone','LIKE',$phone)->get();
        }
        else{
            $outgoing_call=outgoing_call::all();
        }
        return view('call_center.outgoing_call.alloutgoing_call',compact('outgoing_call'));
    }

    public function create()
    {
        $agents = call_agent::all();
        $contact_group=contact_group::all();
        return view('call_center.outgoing_call.addoutgoing_call',compact('contact_group', 'agents'));
    }

    public function store(Request $request)
    {
        $rules=[
            'client_phone' => 'numeric|unique:outgoing_calls',
        ];
        $validator=Validator::make($request->all(),$rules);

        if($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInput($request->all());
        }
        outgoing_call::create([
            'agent_name'=>auth()->user()->name,
            'client_name'=>$request->client_name,
            'client_phone'=>$request->client_phone,
            'call_date' => date('Y-m-d'),
            'lastcalldate'=>$request->lastcalldate,
            'recalldate'=>$request->recalldate,
            'call_case'=>$request->case_percent ? $request->call_case . " " . $request->case_percent : $request->call_case,
            'notes'=>$request->notes,
            'call_group'=>$request->call_group,
            'Appointment_status'=>$request->Appointment_status
        ]);
        return redirect()->back()->with('success', 'Created Successfully');
    }

    public function edit($id)
    {
        $outgoing_call = outgoing_call::find($id);
        return view('call_center.outgoing_call.editoutgoing_call',compact('outgoing_call'));
    }

    public function update(Request $request, $id)
    {
        outgoing_call::find($id)->update($request->all());
        return redirect()->back()->with('success','Updated Successfully');
    }

    public function destroy($id)
    {
        outgoing_call::find($id)->delete();
        return redirect()->route('outgoing_call.index');
    }
}

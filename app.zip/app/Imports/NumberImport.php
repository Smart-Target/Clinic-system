<?php

namespace App\Imports;

use App\Models\PhoneNumber;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class NumberImport implements ToModel //, withHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        $time = time();
        return new PhoneNumber([
            'phone_id' => $row[0],
            'phone_number' => $row[1],
            'group_id' => $time
        ]);
    }
}

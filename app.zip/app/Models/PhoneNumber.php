<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PhoneNumber extends Model
{
    use HasFactory;
    protected $table = 'phone_nubmers';
    protected $fillable = [
      'phone_number',
      'phone_id',
      'group_id',
    ];
}

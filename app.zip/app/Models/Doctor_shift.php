<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Doctor_shift extends Model
{
    use HasFactory;
    protected $table = 'doctor_shift';
    protected $fillable = [
        'doctor_name',
        'start_shift',
        'end_shift',
        'created_at',
        'updated_at',
    ];
    protected $hidden = [
        'created_at',
        'updated_at',
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NurseShift extends Model
{
    use HasFactory;
    protected $table = 'nurses_shift';
    protected $fillable = [
        'nurse_name',
        'start_shift',
        'end_shift',
        'created_at',
        'updated_at',
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KnowUs extends Model
{
    use HasFactory;
    protected $table = 'know_us';

    protected $fillable = [
        'title',
        'created-at',
        'updated_at',
    ];

    protected $hidden = [
        'created-at',
        'updated_at',
    ];
}
